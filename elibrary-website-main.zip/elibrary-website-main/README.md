# elibrary-website
Library website made with HTML/CSS/Javascript and backend in Node.js, Express.js with jwt authentication and SQL database<br />
Complete
